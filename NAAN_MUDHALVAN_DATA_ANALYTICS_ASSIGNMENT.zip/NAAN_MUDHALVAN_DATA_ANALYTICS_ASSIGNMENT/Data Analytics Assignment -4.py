#Task - 1    Create two list and join those two list
list1 =['a','b',1,2,3,'h']
list2=['data','analytics', 'nan mudhalvan']
list3=list1+list2
print(list3)


#Task - 2 With If statement find the even numbers
a=int(input("Enter your Input"))
if a%2==0:
    print(a, "is an even number")
    


#Task - 3 Create a dictionary with 3 keys and 2 values for each key
dict={'roll no':'2001 ,2002'  , 'courses':'Data Analytics , Data Science' , 'scores':'200,260'}
print(dict)


#Task - 4 Create a function with If statement whis is used to find the odd numbers
def is_odd(num):
    if num % 2 != 0:
        return True
    else:
        return False
# Example usage:
number = int(input("Enter a number: "))
if is_odd(number):
    print(f"{number} is an odd number.")
else:
    print(f"{number} is not an odd number.")


#task 5 --Write a Python function to sum all the numbers in a list
list=[3,4,5,7,9,0]
print(sum(list))

